# TR-300

[![CI](https://github.com/QubeTX/qube-machine-report/actions/workflows/ci.yml/badge.svg)](https://github.com/QubeTX/qube-machine-report/actions/workflows/ci.yml)
[![Release](https://github.com/QubeTX/qube-machine-report/actions/workflows/release.yml/badge.svg)](https://github.com/QubeTX/qube-machine-report/actions/workflows/release.yml)
[![License](https://img.shields.io/badge/license-PolyForm%20Noncommercial-blue.svg)](LICENSE)

Cross-platform system information report with Unicode box-drawing tables.

TR-300 is a standalone Rust CLI for fast, reliable, and readable terminal machine reports.

Current release: [latest](https://github.com/QubeTX/qube-machine-report/releases/latest).
The recommended install is the managed CLI command: PowerShell on Windows and
the shell installer on macOS/Linux. Optional Global/Corporate MSI/EXE packages
and a direct universal macOS PKG remain first-class, origin-preserving channels.
None requires Rust on the install machine. The crates.io package is
[`tr300`](https://crates.io/crates/tr300).

v4 is a major release for Rust-library SemVer only: public
information records gained fields and are now non-exhaustive. The `tr300`
command, existing schema-v1 JSON keys, installer names, and update path remain
compatible. Applications that directly construct or exhaustively match public
Rust records must use constructors/default updates or non-exhaustive matching.
The high-level collection/report APIs remain available.

## Features

- Cross-platform support (Windows, macOS, Linux)
- Beautiful Unicode box-drawing tables with ASCII fallback
- ASCII fallback mode for legacy terminals
- Bar graphs for CPU load, memory, and disk usage
- VPN-aware network information on Windows — `MACHINE IP` and `DNS IP` rows reflect the active default route (`GetBestInterfaceEx`-driven) so Tailscale / WireGuard / OpenVPN / corporate VPN tunnels are reported correctly instead of a coin-flip pick
- Hypervisor / virtualization detection (CPUID-based; disambiguates Win11 VBS from real VMs)
- Session info with last-login/current-session tracking; Windows uses WTS APIs with a boot-time fallback
- Disk encryption status (FileVault on macOS, BitLocker on Windows, and root
  encryption signals on Linux when readable)
- Native macOS detail from a single structured snapshot: model, OS build/name,
  real Normal/Safe/Recovery boot state, Apple chip and P/E topology, logical and
  native display resolution, battery health/cycles, and explicit Rosetta host /
  process architecture without leaking hardware identifiers
- Fast Startup-aware uptime on Windows — when the kernel session age and the WMI cold-boot time diverge by >1h (typical on Win10/Win11 laptops with `HiberbootEnabled`), the `UPTIME` row renders both as `9d 4h 12m (session: 7h 14m)`
- 5-state battery awareness on Windows — distinguishes `AC Power` (plugged in, fully topped up), `X% (Charging)`, `X% (Plugged in)` (gaming-laptop case where peak GPU draw exceeds the brick wattage, OR firmware-limited charging modes like ThinkPad battery longevity), `X% (Discharging)`, plus `Critical` / `Low` overrides
- Smart terminal detection on Windows — env-var pre-checks (`WT_SESSION`, `TERM_PROGRAM`, `CURSOR_TRACE_ID`) then a parent-process walk via Toolhelp32 that recognizes Windows Terminal, WezTerm, Alacritty, VS Code, Cursor, Windsurf, Hyper, Tabby, Ghostty, Kitty, MinTTY, Claude Code, and Antigravity even when env vars are absent
- PowerShell 7+ ("PowerShell Core") detection on Windows — reads `HKLM\SOFTWARE\Microsoft\PowerShellCore\InstalledVersions\<GUID>\SemanticVersion` so `pwsh` users see the actual installed version instead of falling back to Windows PowerShell 5.x
- Schema-versioned JSON output for scripting, including collection mode and
  explicit CPU-load, frequency, disk, and memory value definitions
- Read-only ordinary reports with explicit, collision-safe Markdown saving via
  `-r`/`--report`/`-s`/`--save`
- Fast mode (`--fast`) for sub-second auto-run startup
- A real PATH-level `report` command installed beside `tr300`; both names
  support the same reporting options and install/update/uninstall actions
- Thermal reporting (`CPU TEMP` / `GPU TEMP`): Linux reads hwmon package/SoC sensors with a cpu/soc thermal-zone fallback (Raspberry Pi SoC temperature included), Windows reports discrete NVIDIA GPU temperature via the driver tool when an NVIDIA adapter is present; rows appear in both fast and full runs and omit themselves when no trusted sensor exists
- Positional action syntax (`tr300 update`, `tr300 install`, `tr300 uninstall`) with legacy flag compatibility
- Origin-preserving self-update: MSI, EXE, Cargo, shell/PowerShell, and macOS
  PKG installs update through the same channel and never silently create a
  second installer family
- Endpoint-policy-aware update failure: antivirus/Group Policy write or launch
  blocks retain the current install, stop additional write-heavy fallbacks, and
  return actionable manual-release guidance
- Conditional platform detail rows for machine model, CPU core topology, ZFS health, motherboard, BIOS, and RAM slots when the host exposes them
- Optional shell-profile auto-run configuration via `tr300 install`

## Installation

TR-300 ships **prebuilt binaries**—no Rust toolchain is required. The managed
CLI installers are the recommended default because they are per-user, work the
same way across products, and retain a receipt that `tr300 update` can follow.

### Recommended: managed CLI install

**Windows (PowerShell):**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-installer.ps1 | iex"
```

This installs `tr300.exe` and `report.exe` to `%USERPROFILE%\.cargo\bin`, prepends that directory
to your user PATH, and records the `powershell-installer` channel. Rust is not
required. If an exact TR-300 MSI or EXE product is already registered, the
  fresh command verifies its new binary/receipt first, then uses that product's
  real uninstaller (with normal UAC only for machine-wide products) so the
  PowerShell channel becomes the only active owner. If authorization or cleanup
  fails, it restores the prior managed/Cargo binary and receipt and reports the
  native owner that remains.

**macOS or Linux:**

```bash
curl --proto '=https' --tlsv1.2 -LsSf https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-installer.sh | sh
```

This installs `tr300` and `report` to `~/.cargo/bin`, configures your shell PATH, and records
the `shell-installer` channel. On macOS, a fresh shell install can supersede an
  existing TR-300 PKG only after its exact receipt, payload ownership, and
  Developer ID identity agree; it then requests normal administrator approval to
  remove that system package. A cancelled or failed takeover restores the prior
  managed/Cargo binary and receipt. Linux has no competing native package
  channel.

These public commands and asset names never contain a version. Each downloaded
wrapper is nevertheless bound to its immutable release tag and downloads the
exact cargo-dist installer and archive from that tag.

### Optional native installers

Use a native package when system-wide deployment, MDM, managed-installer policy,
or a graphical installer is the better fit. A later `tr300 update` stays on the
native format, edition, and scope you chose.

#### Windows — Global Edition

Installs `tr300.exe` and `report.exe` to `C:\Program Files\tr300\bin` and adds it to **system PATH**
so every terminal on the machine can find it. **Requires admin (UAC prompt).**

Two equivalent download options — pick the format you want to keep using.
Both install to the same location; a later explicit install of the other format
is treated as your newest choice and removes the competing registration first.

| Format | Direct download | When to pick |
|---|---|---|
| MSI | [tr300-x86_64-pc-windows-msvc.msi](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-x86_64-pc-windows-msvc.msi) | IT-managed deployment (Intune, SCCM, Group Policy) and the usual native-package choice. |
| EXE | [tr300-x86_64-pc-windows-msvc-setup.exe](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-x86_64-pc-windows-msvc-setup.exe) | If you prefer a familiar `setup.exe`. Same outcome as the MSI. |

After install, open a new terminal and run `tr300`. The binary is unsigned, so
SmartScreen will show **"Windows protected your PC"** the first time —
click **More info → Run anyway**. (Code signing is on the roadmap;
see [Releases](https://github.com/QubeTX/qube-machine-report/releases) for
status.)

#### Windows — Corporate Edition

Installs `tr300.exe` and `report.exe` to `%LocalAppData%\Programs\tr300\bin` and adds it to your
**user PATH** only — no admin, no UAC, no system-wide changes. Use this on
machines managed by Intune / Active Directory / Group Policy when you don't
have admin rights but still need to install software.

| Format | Direct download | When to pick |
|---|---|---|
| MSI | [tr300-x86_64-pc-windows-msvc-corporate.msi](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-x86_64-pc-windows-msvc-corporate.msi) | IT can push this via Intune assignment; works under AppLocker / managed-installer policy when allowlisted. |
| EXE | [tr300-x86_64-pc-windows-msvc-corporate-setup.exe](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-x86_64-pc-windows-msvc-corporate-setup.exe) | Familiar `setup.exe` for end users on restricted machines. |

Same channel-choice rule as the Global Edition. If WDAC / AppLocker blocks
both, your only options are the bare-EXE path below or asking IT to allowlist
one of these installers.

#### Choosing between Global and Corporate Edition

If you are deliberately choosing a native Windows package:

| You're on… | Pick |
|---|---|
| Your own laptop / desktop, you have admin | **Global** |
| A work machine where you have admin | **Global** |
| A work machine where you don't have admin but can install apps to your user profile | **Corporate** |
| A locked-down machine that blocks `C:\Program Files` writes | **Corporate** |
| A server, ARM Windows, or anything else | Use the bare EXE / shell installer below |

Current Windows native installers treat an explicit fresh launch as your newest
channel choice. They strictly retire an exact older managed/Cargo copy and
refuse to claim success when ownership is ambiguous or another edition cannot
be retired safely. There is no cleanup opt-out: use a portable archive if you
intentionally want an unmanaged side-by-side copy. The v4.3 direct macOS PKG
uses the safer, asymmetric rule described below.

#### macOS universal PKG

Download [tr300-universal-apple-darwin.pkg](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-universal-apple-darwin.pkg),
open it, and follow Apple Installer. The universal package supports
Apple Silicon and Intel, installs `/usr/local/bin/tr300` and
`/usr/local/bin/report` system-wide, and records
the stable `com.qubetx.tr300.pkg` receipt used by `tr300 update`. The updater
also requires that receipt's version, payload path, per-file ownership, and the
installed binary's Developer ID product identity to match; a stale receipt is
not enough.

**v4.3+ policy:** the direct PKG never removes a per-user
managed/Cargo install. Its `preinstall` checks every direct directory entry in
`/Users`—including dot-prefixed and unregistered residue—plus all eligible local
Directory Service homes, independent of console or launch environment. For each
home it performs a bounded, non-recursive inspection of only the exact parent
levels leading to the standard managed commands at `~/.cargo/bin/tr300` and
`~/.cargo/bin/report`, plus the receipt
at `~/.config/tr300/tr300-receipt.json`; it enumerates each existing parent before
treating the fixed path as absent. Abnormal entry types, broken links, or an
unlistable intermediate directory fail closed before `/usr/local/bin/tr300` or
`/usr/local/bin/report` is
installed. Arbitrary custom cargo-dist prefixes, `CARGO_HOME`, or XDG
configuration roots are not discoverable from PackageKit; keep using the managed
installer or explicitly retire that custom owner before launching the PKG. The
PKG also accepts only the current system volume (`/`). To switch from the managed
channel, first refresh or reinstall that copy through the v4.3-or-later managed
installer, run `tr300 uninstall`, choose **Complete**, and then launch the PKG. The
Complete path removes both managed commands and the exact matching
cargo-dist receipt as one fail-closed transaction. Malformed, foreign, linked,
or changing receipt evidence is preserved for review. A clean PKG install,
same-version repair, and native PKG upgrade remain supported. The v4.2.2 PKG
predates this policy; the receipt-aware transition sequence requires v4.3 or
later.

This safety check is deliberately fail-closed. If a normal local account's
Directory Service home is missing, offline, or otherwise uninspectable, the PKG
will stop without an override. Make that declared home available, repair the
account's Directory Service home record, or keep using the managed installer.

The binary and PKG are Developer ID signed. Before publication, GitHub's native
Apple Silicon and Intel runners require Apple Notary Service acceptance, staple
and Gatekeeper-check the candidate PKG and DMG, install the PKG directly, run its
report/lifecycle checks, and verify uninstall contents. The real public updater
matrix, immutable-v4.1.x compatibility bridge, and published Linux/macOS smokes
run only after the exact 34-asset release is public. A physical Mac is optional
visual testing, not a release gate.

Releases also retain a signed compatibility DMG containing the byte-identical
PKG because immutable v4.1.x updaters require that exact legacy filename. New
installs and v4.2.0+ self-updates never mount it.

To remove the system package and its receipt:

```bash
sudo rm -f /usr/local/bin/tr300 /usr/local/bin/report
sudo pkgutil --forget com.qubetx.tr300.pkg
```

The PKG contains only those two versionless commands. The hosted uninstall gate
checks the same inventory after every release.

### Alternative install methods

<details>
<summary>Windows — bare EXE (no installer, no PATH modification)</summary>

Download [tr300-x86_64-pc-windows-msvc.zip](https://github.com/QubeTX/qube-machine-report/releases/latest/download/tr300-x86_64-pc-windows-msvc.zip),
extract `tr300.exe` and `report.exe`, and keep them together anywhere you can write to (your Desktop, a
USB stick, `C:\bin`, etc.). Run by typing the full path or by adding the
containing directory to your PATH manually. Useful for portable use, USB
sticks, and scenarios where any installer is blocked.
</details>

<details>
<summary>Build from source — for developers / contributors</summary>

Requires Rust **1.95.0 or later** (`rustup update stable` if needed).
Most users should NOT use these paths — they download and compile the
source instead of using the prebuilt binary, which is slower and requires
the Rust toolchain.

**From crates.io:**
```bash
cargo install tr300
```

**From a specific Git tag:**
```bash
rustup update stable
cargo install --git https://github.com/QubeTX/qube-machine-report.git --tag "$(gh release view --json tagName --jq .tagName)"
```

**Local clone for development:**
```bash
git clone https://github.com/QubeTX/qube-machine-report.git
cd qube-machine-report
cargo build --release
```
</details>

## Usage

```bash
# Display system report without creating a report file (default)
tr300

# Equivalent PATH command (same full report by default)
report

# Fast report / JSON / explicit full report
report --fast
report --json
report --full

# Either name supports maintenance
report update

# Use ASCII characters instead of Unicode
tr300 --ascii

# Output as JSON
tr300 --json

# Save the full table as a Markdown report in Downloads
tr300 --report
# Equivalent save forms:
tr300 -r
tr300 --save
tr300 -s

# Custom title
tr300 --title "MY SERVER"

# Disable colors
tr300 --no-color

# Self-update to the latest release
tr300 update
# Legacy form still works:
tr300 --update

# Install to shell profile (adds 'report' alias + auto-run)
tr300 install
# Legacy form still works:
tr300 --install

# Remove from the shell profile, or choose Complete for the binary and
# an exact matching managed receipt
tr300 uninstall
# Legacy form still works:
tr300 --uninstall

# Show help
tr300 --help
```

## Example Output

```
┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐
├┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┤
│            QUBETX DEVELOPER TOOLS                 │
│             TR-300 MACHINE REPORT                 │
├──────────────┬────────────────────────────────────┤
│ OS           │ Windows 11 24H2                    │
│ KERNEL       │ Windows 10.0.26200                 │
├──────────────┼────────────────────────────────────┤
│ HOSTNAME     │ DESKTOP-ABC123                     │
│ MACHINE IP   │ 192.168.1.100                      │
│ CLIENT  IP   │ Not connected                      │
│ DNS  IP 1    │ 192.168.1.1                        │
│ USER         │ emmett                             │
├──────────────┼────────────────────────────────────┤
│ PROCESSOR    │ Intel Core Ultra 7 155H            │
│ CORES        │ 22 vCPU(s) / 1 Socket(s)           │
│ HYPERVISOR   │ Bare Metal                         │
│ CPU FREQ     │ 1.4 GHz                            │
│ LOAD  1m     │ ███████░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
│ LOAD  5m     │ █████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
│ LOAD 15m     │ ████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
├──────────────┼────────────────────────────────────┤
│ VOLUME       │ 848.18/935.54 GB [90.66%]          │
│ DISK USAGE   │ █████████████████████████████░░░░░ │
├──────────────┼────────────────────────────────────┤
│ MEMORY       │ 18.00/31.52 GiB [57.1%]            │
│ USAGE        │ ██████████████████░░░░░░░░░░░░░░░░ │
├──────────────┼────────────────────────────────────┤
│ LAST LOGIN   │ Jul 13 22:41                        │
│ UPTIME       │ 5h 38m                             │
├──────────────┴────────────────────────────────────┤
└──────────────┴────────────────────────────────────┘
```

## Command Line Options

Positional actions can be written without a double dash. They are mutually
exclusive with each other and with the legacy action flags.

| Action | Description |
|--------|-------------|
| `update` | Check for updates and install the latest version |
| `install` | Configure the optional shell-profile auto-run block |
| `uninstall` | Remove the profile block, or choose Complete for both commands and an exact matching managed receipt |

| Option | Description |
|--------|-------------|
| `--ascii` | Use ASCII characters instead of Unicode |
| `--json` | Output in JSON format |
| `-t, --title <TITLE>` | Custom title for the report header |
| `--no-color` | Disable colored output |
| `--fast` | Fast mode: skip slow collectors for quick auto-run |
| `-f, --full` | Explicit full collection (already the default; conflicts with `--fast`) |
| `-r, -s, --report, --save` | Save this full table report as Markdown in Downloads |
| `--no-elevation-hint` | Suppress the optional Linux `sudo` detail hint |
| `--update` | Legacy flag form of `tr300 update` |
| `--install` | Legacy flag form of `tr300 install` |
| `--uninstall` | Legacy flag form of `tr300 uninstall` |
| `-h, --help` | Print help information |
| `-V, --version` | Print version information |

The packaged `report` command accepts every option and action in this table,
including install, update, and uninstall. It is a full alias for `tr300` on
Windows, macOS, and Linux. Keep `report` beside `tr300`; it delegates only to
that exact adjacent payload, never to a PATH-resolved executable. Both names
show the same help and version text and propagate the same exit status.

`tr300 config` is not a command. Configuration remains CLI-driven; passing the
word `config` is rejected as an invalid action.

## Self-Update

Both action forms update to the latest release:

```bash
tr300 update
tr300 --update
```

`tr300 update` detects how this binary was installed and downloads the matching
installer for an **in-place upgrade**. It preserves installer format, edition,
scope, and recorded directory: Corporate MSI stays Corporate MSI, Global EXE
stays Global EXE, Cargo stays Cargo, shell/PowerShell stays at its receipt
prefix, and a macOS PKG opens the verified universal PKG in Apple Installer.

**Fresh install and update are different operations.** A CLI update is
latest-only and preserves its proven channel. A fresh installer expresses a new
choice, including a same-version or downgrade reinstall, only within a platform
transaction that can prove the ownership change. Windows native installers and
the managed wrappers retire recognized prior TR-300 ownership. Beginning with
v4.3, a direct macOS PKG instead refuses standard managed
ownership during `preinstall`; switching to it requires the receipt-aware
Complete-uninstall sequence above. Ambiguous evidence or failed authorization
always returns a visible failure and recovery guidance.

The bounded Windows consolidation code deletes only the allowlisted `tr300`
binary and an exactly matching cargo-dist receipt—never Cargo/rustup, the Cargo
PATH entry, Downloads, or the running copy. Windows native installers have no
cleanup checkbox or silent opt-out. The v4.3+ macOS PKG
contains no postinstall migration helper and performs no privileged user-home
mutation.

**On Windows (v3.15.0+):**

| Installed via… | `tr300 update` does | UAC? |
|---|---|---|
| Global MSI | Downloads the new Global MSI, runs `msiexec /i` | Yes |
| Corporate MSI | Downloads the new Corporate MSI, runs `msiexec /i` | No |
| Global EXE | Downloads the new Global EXE installer, runs `/SILENT` | Yes |
| Corporate EXE | Downloads the new Corporate EXE installer, runs `/SILENT` | No |
| PowerShell installer | Downloads the exact-tag PowerShell installer into the recorded prefix | No |
| `cargo install` | Runs exact `cargo install --version … --force --locked` | No |

The PowerShell row refers to the managed `irm` installer shown above. A raw
`cargo install tr300 --force` has no post-install hook, so it cannot retire an
MSI/EXE registration at install time. It remains an advanced, unmanaged fresh
install path; once unambiguously running as Cargo, its CLI updater stays Cargo.

All recognized Windows channels use a transactional running-image handoff: the
old command is kept under a private sibling name while the preserved channel
installs and verifies the replacement, then the new command removes that backup
after the updater exits. Global MSI/EXE perform only that transaction inside a
strict elevated worker, so you receive one normal UAC prompt and the ordinary
parent remains alive to return the final result. A failed replacement restores
the old executable before returning exit code 2; UAC cancellation happens
before the Program Files command is renamed.

Detection prefers separate Global/Corporate registry markers while preserving
the legacy `HKCU\Software\TR300\InstallSource` value. A missing marker is
recovered only when Add/Remove Programs and the running path identify one
unambiguous MSI or Inno product. Cargo metadata and cargo-dist receipts separate
the two `~\.cargo\bin` channels. Conflicting, portable, or unknown origins do
not mutate the machine; they fail safely with the fresh installer link.

**Download integrity:** every downloaded MSI / EXE / PKG (and the legacy DMG)
is checked against
its published `.sha256` sidecar before launching. This catches truncation,
cache corruption, and payload/sidecar mismatch. Because both files use the
same HTTPS release transport, the checksum is not an independent signature;
Windows installer signing, Apple Developer ID/Gatekeeper, and the official
GitHub release channel provide the platform trust boundary.

**Post-install verification (v3.15.2+):** after the installer reports success,
`tr300 update` re-execs the on-disk binary's `--version` and confirms the
upgrade actually took effect. If Windows Installer's Restart Manager
scheduled a delete-on-reboot (msiexec exit code 3010 or 1641) rather than replacing
the locked binary in-place, the JSON `attempts[].message` contains an
actionable "Reboot, then verify with `tr300 --version`" rather than a
false-positive success.

**Endpoint-policy failure (v4.0.0+):** if antivirus, Group Policy, AppLocker,
or filesystem policy appears to block installer staging, a staged write, or
installer launch, TR-300 stops the fallback chain instead of trying more
write-heavy methods. The current installation is left in place, the update
returns exit code 2, and terminal/JSON output records the attempt as `blocked`
with the official release/manual-install link. There is no force/direct binary
replacement path.

**On macOS / Linux:**

TR-300 first resolves the latest GitHub release once, then preserves the
detected install channel. A macOS PKG receipt selects the verified direct
universal PKG and Apple Installer. A cargo-dist receipt selects the exact-tag shell
installer and its recorded prefix. Cargo metadata selects
`cargo install tr300 --version <resolved-version> --force --locked`; a
best-effort `rustup update stable` runs first when available. No Unix channel
falls through into another channel. Unknown or conflicting origins are left
untouched and receive recovery links.

**Manual fallback (any platform):** if `tr300 update` fails, you can always
rerun the recommended versionless CLI install command or choose a package from
the [latest release page](https://github.com/QubeTX/qube-machine-report/releases/latest).
An explicitly launched older or same-version managed/native installer still
represents the user's latest instruction; the automatic updater remains
latest-only and never changes channels.

In `--json` mode, stdout is always exactly one JSON object; installer progress
is kept on stderr. Every response includes `install_channel`, `recovery_url`,
and `requires_user_action`. Windows retains its compatible top-level
`install_origin` field (`msi-global` / `msi-corporate` / `exe-global` /
`exe-corporate` / `cargo-or-installer` / `unknown`). Successful updates retain
the legacy `method` field plus the precise `strategy`; failed updates retain
the existing attempts diagnostics and manual-install fields. A failed known
installer channel also includes `exact_installer_url` for the immutable tagged
asset; `recovery_url` remains the versionless latest release page. Cancellation,
policy blocking, a required reboot, an ambiguous origin, or a failed Apple
Installer prompt exits 2 and points to both the matching tagged payload (when
known) and the versionless latest release page.

## Release Automation

GitHub Actions handles both release assets and crates.io publishing through
protected, exact-source workflows:

- `CI` runs formatting, clippy, tests, release builds, speed checks, audit, and
  cargo-dist planning on pushes to the default branch. Native Apple Silicon and
  Intel macOS jobs plus AMD64/ARM64 Linux and Windows jobs are blocking, and
  workflow/shell validation runs in the same gate.
- A same-repository push to `main` starts `Crates.io Publish` automatically.
  Its read-only Cargo 1.95 job has no registry credential and waits for that
  exact SHA's `CI` run to pass before it builds and verifies the normalized package; a
  fresh protected `crates-io` job reproduces the exact crate bytes, mints a
  short-lived OIDC token only for `cargo publish --no-verify`, and requires the
  public checksum and trusted-publisher provenance to match the repository,
  run, and source SHA. If the version already exists with the expected bytes,
  the workflow exits successfully without minting a publish token.
- `Release` is the cargo-dist workflow triggered by an explicit stable
  `vX.Y.Z` tag. Builders use only read-only GitHub authorization with checkout
  credential persistence disabled; fresh checkout-free Apple signers produce
  the cross-platform archives, managed `tr300-installer.*` wrappers, internal
  `tr300-dist-installer.*` transactions, and `tr-300-installer.*` compatibility
  aliases. A fresh publisher creates a **private 24-asset draft**; it never
  exposes a partial stable release. The cargo-dist config permits the reviewed
  workflow/MSI customizations with `allow-dirty = ["ci", "msi"]`.
- `Windows Installers` adds the Corporate MSI and both Global/Corporate Inno
  EXEs plus their sidecars through a fresh publisher, producing a private
  30-asset candidate. `Windows Installer Validation` freezes those exact bytes,
  runs authenticated direct prior-to-candidate install/transition/uninstall
  checks while public `latest` remains unchanged, and emits immutable acceptance
  evidence.
- `macOS Universal Package` consumes the exact Release-run Apple archives and
  the Windows acceptance proof, builds/signs/notarizes the universal direct PKG
  and compatibility DMG, and exercises both on native Apple Silicon and Intel.
  Its sole fresh finalizer rechecks every accepted byte, adds four assets, and
  is the only workflow allowed to publish the exact 34-asset release. Only then
  do the real public updater matrix and published Linux/macOS smokes run. A
  physical Mac remains an optional visual smoke test, not a release dependency.

`Cargo.lock` is tracked so the crates.io publish workflow uses the same resolved
dependency set that local release verification used.

## Elevation Tier

TR-300 detects whether it is running with elevated privileges (root on Unix /
Administrator on Windows) and exposes that fact to JSON consumers.

- **Linux, unelevated** — a single dim footer notes that `sudo` may unlock RAM
  module details when `dmidecode` is installed. The hint is never shown during
  `--fast` auto-run.
- **Linux, elevated** — available `dmidecode` details render inline.
- **Windows and macOS** — no blanket elevation promise is shown. Optional
  BitLocker/FileVault data is reported when the OS exposes it; a missing value
  does not prove that Administrator or `sudo` would fix the probe.

To opt out of the hint, run `tr300 --no-elevation-hint` (or wire the flag into your
shell alias). The hint is rendered with ANSI dim, so respects `--no-color` as well.

The JSON output exposes this state under top-level keys `elevated` and
`elevation_unlocks_more` for scripted consumers.

## Installation to Shell Profile

Running `tr300 install` or `tr300 --install` will:

1. **Remove existing TR-300 configuration** (if present)
2. Remove the legacy TR-300-owned `report` alias from that block
3. Configure auto-run on new interactive shell sessions

The real `report` command is installed by every v4.4+ package beside `tr300`
and does not depend on shell profiles. Existing users can rerun `tr300 install`
once after upgrading to retire an old profile alias; foreign aliases or
functions named `report` are warned about and preserved.

This means you can safely run `tr300 install` multiple times without duplicating profile blocks.

**Safety (v3.15.2+):** every modification to your rc files / `$PROFILE`
is written via a temp-then-atomic-rename. A Ctrl-C, power loss, or
antivirus quarantine mid-write can no longer leave your profile
truncated. The first install also writes a one-time `.tr300-backup`
copy of your original profile so you have a recovery option. If the
TR-300 marker block in your profile has been hand-edited into an
unbalanced state (e.g. `# End TR-300` line accidentally removed),
`tr300 install` refuses up-front with an actionable error rather
than silently dropping the rest of your profile.

**Auto-run guards (v3.15.2+):** the injected snippet now guards
the `tr300 --fast` call with `command -v tr300` (POSIX) /
`Get-Command tr300 -ErrorAction SilentlyContinue` (Windows), so a
missing binary no longer prints an error at every new shell start.
A `TR300_AUTORUN_RAN` sentinel prevents recursion in nested shells
(vim `:term`, `bash -i -c …`, Windows Terminal nested tabs). On
Windows, the snippet uses `[Environment]::UserInteractive` instead
of the older `$Host.Name -eq 'ConsoleHost'` check, so scripted
`pwsh -Command "..."` invocations from CI / VS Code / scheduled
tasks no longer dump the table into log streams.

**On Unix/macOS:** Modifies `~/.bashrc` and/or `~/.zshrc`. On a
fresh-account macOS machine where neither file exists, `tr300
install` creates `.zshrc` (macOS has defaulted to zsh since 10.15,
Catalina, 2019). `sudo tr300 install` is refused — TR-300 modifies
your personal shell profile, and running as root either targets
root's profile (no benefit to your shell) or leaves root-owned
files in your home that break subsequent non-sudo installs.

**On Windows:** Modifies the PowerShell `$PROFILE`. When both
Windows PowerShell 5.1 (`powershell`) and PowerShell 7 (`pwsh`)
are installed, `tr300 install` writes to BOTH profile paths
(`Documents\WindowsPowerShell\…` and `Documents\PowerShell\…`)
since the two shell flavors don't cross-source each other.
Pre-v3.15.2, pwsh-only users got a silent no-op install because
the snippet went to a profile their actual shell never read.

Fresh Windows machines default `ExecutionPolicy` to `Restricted`,
which blocks every `.ps1` including the profile itself, so
`tr300 install` runs a preflight that adjusts the `CurrentUser`
scope to `RemoteSigned` when needed. `RemoteSigned` is the minimum
policy that lets the local profile load — it still requires
downloaded `.ps1` files to be Authenticode-signed. The change is
HKCU-only, affects only your user account, and does not require
admin. If you have deliberately set `AllSigned`, `tr300 install`
will not silently downgrade it; it prints a notice explaining the
auto-run will not fire and leaves the policy alone.
See [Microsoft Learn — about_Execution_Policies](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies).

To remove these additions, run `tr300 uninstall` or `tr300 --uninstall`.
The uninstall does not roll back your execution policy — other PowerShell
tooling typically relies on `RemoteSigned`, so restoring it would surprise
users.

Beginning with v4.3 on macOS/Linux, **Complete** also recognizes a
running cargo-dist-managed copy. It validates the standard receipt's provider,
app, and exact install prefix before changing profiles, then removes the binary
and receipt transactionally. A raw Cargo install with no receipt still removes
only its binary. Unsafe evidence found during preflight leaves the installation
and profiles unchanged. If ownership changes after confirmation, the final
revalidation preserves the binary and receipt, but the profile block may
already have been removed; the diagnostic explains how to restore it.

**`uninstall` → Complete** on Windows handles the self-EXE delete case
(v3.15.2+). When you run `tr300 uninstall` from a Windows install
location (e.g. `%LocalAppData%\Programs\tr300\bin\tr300.exe`) and
choose "Complete", the OS would normally refuse to delete the
running binary. TR-300 detects this and schedules a detached
background job that waits 2 seconds for our process to exit, then
removes the binary and its empty parent folder. You'll see
"Scheduled deferred cleanup of: …" and your shell returns to a
prompt; the file is gone within a couple seconds.

If `tr300 install` (or `uninstall`) hits a permissions error on Windows —
common on work machines managed by Intune, Group Policy, AppLocker, or
WDAC, and on personal machines where Documents is redirected to OneDrive
— the tool prints a multi-paragraph explanation of what likely caused the
failure (OneDrive offline / online-only files, an MDM lockdown, antivirus
blocking the profile edit, a sharing violation, a disk-full condition, or
a MAX_PATH overflow) along with concrete next steps: which path to ask IT
to allowlist, where to add an antivirus exclusion, or how to `takeown`
ownership. Manual `tr300` invocations from the prompt always continue to
work in this case; only the auto-run on new shells is affected, and you
can re-run `tr300 install` once the underlying restriction is addressed.

## Building from Source

Requirements:
- Rust 1.95.0 or later (`rustup update stable`)
- Cargo

```bash
# Debug build
cargo build

# Release build
cargo build --release

# Run tests
cargo test --workspace --all-targets

# Run clippy
cargo clippy --all-targets --workspace -- -D warnings

# Check formatting
cargo fmt --all -- --check

# Audit the locked dependency graph
cargo audit

# Run with arguments
cargo run -- --ascii
```

### Rust library migration for v4

The high-level APIs remain the preferred path:

```rust,no_run
use tr300::{report, CollectMode, Config, SystemInfo};

let info = SystemInfo::collect_with_mode(CollectMode::Full)?;
let rendered = report::generate(&info, &Config::default());
println!("{rendered}");
# Ok::<(), tr300::AppError>(())
```

Public data records and extensible enums are now `#[non_exhaustive]`. Downstream
code may read public fields, but should stop constructing those records with
external struct literals and should include a wildcard arm when matching public
enums. The CLI and existing schema-v1 JSON keys do not require migration.

### Man Pages (Linux/macOS)

The `tr300(1)` and `report(1)` pages are auto-generated from the
same clap definitions as `--help`, so their documented actions and options stay
in sync with each command. After building from source:

```bash
sudo cp man/tr300.1 man/report.1 /usr/local/share/man/man1/
man tr300
man report
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the PolyForm Noncommercial License 1.0.0 - see the [LICENSE](LICENSE) file for details. This license permits noncommercial use, personal use, and use by charitable organizations, educational institutions, and government agencies.
